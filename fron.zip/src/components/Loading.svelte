<script>
  import { fade } from "svelte/transition";
</script>

<img transition:fade class="mx-auto" src="/loading.svg" alt="loading" />
