<script>
  export let className = "";
</script>

<svg
  on:click
  xmlns="http://www.w3.org/2000/svg"
  class={'w-6 h-6' + ' ' + className}
  viewBox="0 0 48 48">
  <path d="M0 0h48v48H0z" fill="none" />
  <path d="M6 36h36v-4H6v4zm0-10h36v-4H6v4zm0-14v4h36v-4H6z" />
</svg>
