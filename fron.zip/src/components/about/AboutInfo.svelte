<style>
  strong {
    @apply text-ocitanda-green;
  }

  span {
    height: 75%;
  }
</style>

<article class="relative flex flex-col px-8 py-20 overflow-hidden">
  <p class="text-lg font-bold lg:text-xl w-full md:w-9/12">
    A DP & DEEPL, Comércio e Prestação de Serviços, Lda., doravante referida por
    <strong>DEEPL,</strong>
    é uma sociedade comercial constituída à luz do ordenamento jurídico
    angolano, com sede em Luanda, no Bairro Cassenda, Rua 3, Casa nº 33,
    Distrito Urbano da Maianga, Município e província de Luanda.
    <strong>A DEEPL é detentora da marca OCITANDA.</strong>
  </p>
  <span
    class="absolute right-0 w-1/4 bg-ocitanda-green bg-opacity-25 transform
    -skew-x-12" />
</article>
