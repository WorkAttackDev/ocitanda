<script>
  import ContactBox from "../components/ContactBox.svelte";
  import PageHeader from "../components/PageHeader.svelte";
  import InfoSection from "../components/producer/InfoSection.svelte";
</script>

<style>

</style>

<svelte:head>
  <title>Ocitanda - Política de cookies</title>
</svelte:head>

<section class="flex flex-col m-8 overflow-hidden">
  <h1 class="font-bold text-2xl my-4">O QUE SÃO COOKIES</h1>
  <p class="text-lg">
    O cookie é um ficheiro de informação automaticamente colocado nos discos
    rígidos dos computadores ou dispositivos móveis dos utilizadores quando
    estes acedem a certos websites. O cookie identifica o programa de navegação
    no servidor, possibilitando o armazenamento de informação no servidor, por
    forma a melhorar as experiências dos Utilizadores. A informação recolhida
    respeita às preferências de navegação dos Utilizadores, designadamente a
    forma como os Utilizadores acedem e utilizam o website e a zona do país
    através do qual acedem, entre outros, não incluindo, como tal, informação
    que os identifique, mas meras informações genéricas.
  </p>
  <p class="text-lg">
    A maioria dos programas de navegação estão definidos para aceitar cookies,
    embora seja possível configurar o navegador para recusar todos os cookies ou
    para indicar quando um cookie está a ser enviado, conforme descrito infra.
    Note-se, no entanto, que se recusar os cookies algumas funcionalidades do
    website poderão não funcionar corretamente.
  </p>
  <h1 class="font-bold text-2xl my-4">PORQUE É QUE UTILIZAMOS COOKIES</h1>
  <p class="text-lg">
    O nosso Website utiliza cookies nos termos descritos infra e o OCITANDA é a
    entidade responsável pelo seu tratamento. A utilização de cookies visa
    melhorar o desempenho do nosso Website e maximizar a sua experiência ao
    navegar no mesmo, nomeadamente permitindo uma navegação mais rápida e
    eficiente, eliminando a necessidade de introduzir repetidamente as mesmas
    informações. Esta Política de Cookies explica como o fazemos. De qualquer
    forma, caso tenha alguma dúvida quanto aos termos de funcionamento dos
    cookies utilizados pela OCITANDA, poderá contactar-nos através de
    suporte@ocitanda.com.
  </p>
  <h1 class="font-bold text-2xl my-4">GESTÃO DE COOKIES</h1>
  <p class="text-lg">
    Todos os browsers permitem ao respetivo utilizador aceitar, recusar ou apagar
    cookies, nomeadamente através da seleção das definições apropriadas no
    respetivo navegador. Tenha em atenção, no entanto, que a desativação dos
    cookies pode afetar, parcial ou totalmente, a sua experiência de navegação
    no Website. Pode configurar os cookies no menu “opções” ou “preferências” do
    seu browser. Para saber mais sobre cookies, visite www.allaboutcookies.org,
    onde poderá encontrar informações sobre como gerir as suas configurações
    para os vários fornecedores de navegadores.
  </p>
</section>
