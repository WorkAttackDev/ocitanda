# Ocitanda E-commerce made by WorkAttack.

this is the oficial ocitanda e-commerce

## TODO

-   [x] work on send email.
-   [x] work on user data update.
-   [x] work on delete user.
-   [x] work on about.
-   [x] work on add to Cart.
-   [x] work on remove from the cart.
-   [x] Work on subscription email.
-   [-] whe the user exists made a button to redirect to login.
-   [-] inprove the responsivity.
-   [-] inprove notification component.
-   [-] work on login.
-   [-] work on recover password.
-   [-] work on user page.
-   [-] work on checkout.
-   [] work on create producer.
-   [] work on delete producer.
-   [] work on update producer.
-   [] add real products.
-   [] add admin dashboard.
-   [] work on verify email.
-   [] Work on authentication with sapper.
-   [] Work on refresh token.
