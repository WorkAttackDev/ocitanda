export default (name, href) => ({ name, href });
