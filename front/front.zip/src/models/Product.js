export default (
	id = 0,
	name = "",
	desc = "",
	price = 0,
	producer = "",
	img = ""
) => ({
	id,
	name,
	desc,
	price,
	producer,
	img,
});
