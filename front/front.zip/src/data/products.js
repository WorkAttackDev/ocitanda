import Product from "../models/Product";
export const products = [
	Product(
		"1",
		"Tomate",
		"Nacional. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sed, voluptatem molestiae? Quia repudiandae ullam ipsa id error molestias sunt, pariatur repellendus eius, dicta maxime ad eaque! Enim iusto sequi laboriosam.",
		500,
		"Ocitanda",
		"/products/tomato.jpg"
	),
	Product(
		"2",
		"Cebola",
		"Nacional. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sed, voluptatem molestiae? Quia repudiandae ullam ipsa id error molestias sunt, pariatur repellendus eius, dicta maxime ad eaque! Enim iusto sequi laboriosam.",
		500,
		"Ocitanda",
		"/products/onion.jpg"
	),
	Product(
		"3",
		"Melancia",
		"Nacional. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sed, voluptatem molestiae? Quia repudiandae ullam ipsa id error molestias sunt, pariatur repellendus eius, dicta maxime ad eaque! Enim iusto sequi laboriosam.",
		500,
		"Aldeia Nova",
		"/products/water-melon.jpg"
	),
	Product(
		"4",
		"Alface",
		"Nacional. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sed, voluptatem molestiae? Quia repudiandae ullam ipsa id error molestias sunt, pariatur repellendus eius, dicta maxime ad eaque! Enim iusto sequi laboriosam.",
		500,
		"Ocitanda",
		"/products/lettuce.jpg"
	),
	Product(
		"5",
		"Banana",
		"Nacional. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sed, voluptatem molestiae? Quia repudiandae ullam ipsa id error molestias sunt, pariatur repellendus eius, dicta maxime ad eaque! Enim iusto sequi laboriosam.",
		500,
		"Ocitanda",
		"/products/banana.jpg"
	),
	Product(
		"6",
		"Feijão",
		"Nacional. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sed, voluptatem molestiae? Quia repudiandae ullam ipsa id error molestias sunt, pariatur repellendus eius, dicta maxime ad eaque! Enim iusto sequi laboriosam.",
		500,
		"Lorem Ipsum Dolor",
		"/products/bean.jpg"
	),
	Product(
		"7",
		"Feijão Verde",
		"Nacional. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sed, voluptatem molestiae? Quia repudiandae ullam ipsa id error molestias sunt, pariatur repellendus eius, dicta maxime ad eaque! Enim iusto sequi laboriosam.",
		500,
		"Ocitanda",
		"/products/green-bean.jpg"
	),
	Product(
		"8",
		"Laranja",
		"Nacional. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sed, voluptatem molestiae? Quia repudiandae ullam ipsa id error molestias sunt, pariatur repellendus eius, dicta maxime ad eaque! Enim iusto sequi laboriosam.",
		500,
		"Ocitanda",
		"/products/orange.jpg"
	),
	Product(
		"9",
		"Arroz",
		"Nacional. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sed, voluptatem molestiae? Quia repudiandae ullam ipsa id error molestias sunt, pariatur repellendus eius, dicta maxime ad eaque! Enim iusto sequi laboriosam.",
		500,
		"Ocitanda",
		"/products/rice.jpg"
	),
	Product(
		"10",
		"Morangos",
		"Nacional. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sed, voluptatem molestiae? Quia repudiandae ullam ipsa id error molestias sunt, pariatur repellendus eius, dicta maxime ad eaque! Enim iusto sequi laboriosam.",
		500,
		"Ocitanda",
		"/products/strawberry.jpg"
	),
	Product(
		"11",
		"Cenoras",
		"Nacional. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sed, voluptatem molestiae? Quia repudiandae ullam ipsa id error molestias sunt, pariatur repellendus eius, dicta maxime ad eaque! Enim iusto sequi laboriosam.",
		500,
		"Ocitanda",
		"/products/carrot.jpg"
	),
];
