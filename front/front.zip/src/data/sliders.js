const Img = (src = "", alt = "") => ({ src, alt });
export const sliders = [
	Img("/fruits.jpg", "vegetables"),
	Img("/vegetables_bowls.jpg", "vegetables"),
	Img("/vegetables.jpg", "vegetables"),
	Img("/vegetables_bowls.jpg", "vegetables"),
];
