import Link from "../models/Link";
export const links = [
	Link("Início", "/"),
	Link("Produtos", `/products`),
	Link("Carrinho", "/cart"),
	Link("Fornecedor", "/producer"),
	// Link("Nutrição", "#"),
	Link("Sobre", "/about"),
];
