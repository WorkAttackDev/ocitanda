<script>

</script>

<style>
  main {
    background: linear-gradient(30deg, #2a8e10d1 20%, transparent),
      url(/coming-soon.jpg);
  }
</style>

<main
  class="flex items-center justify-center bg-no-repeat bg-center bg-cover h-full
  w-full">
  <h1 class="text-5xl text-white font-bold tracking-widest">
    Brevemente Estaremos Disponivel
  </h1>
</main>
