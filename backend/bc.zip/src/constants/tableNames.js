module.exports = {
	user: "user",
	province: "province",
	address: "address",
	planting: "planting",
	consumer: "consumer",
	producer: "producer",
	product: "product",
	category: "category",
	purchase: "purchase",
	cart_item: "cart_item",
	subscriber: "subscriber",
	api: "api",
};
